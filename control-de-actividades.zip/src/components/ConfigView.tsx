/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Settings, 
  RefreshCw, 
  Trash2, 
  Upload, 
  Download, 
  Calendar, 
  HelpCircle, 
  Info, 
  Database,
  FileText
} from 'lucide-react';
import { Actividad } from '../types';

interface ConfigViewProps {
  referenceDate: string;
  onUpdateReferenceDate: (date: string) => void;
  onResetToDemoData: () => void;
  onClearData: () => void;
  onImportData: (actividades: Actividad[]) => boolean;
  actividades: Actividad[];
}

export default function ConfigView({
  referenceDate,
  onUpdateReferenceDate,
  onResetToDemoData,
  onClearData,
  onImportData,
  actividades
}: ConfigViewProps) {
  const [tempDate, setTempDate] = useState(referenceDate);
  const [importError, setImportError] = useState('');
  const [importSuccess, setImportSuccess] = useState('');

  // Cambiar fecha de simulación
  const handleDateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempDate) return;
    onUpdateReferenceDate(tempDate);
    alert(`Fecha de control actualizada a: ${tempDate}. Todos los cálculos de avance y atrasos se han recalculado.`);
  };

  // Exportar base de datos a JSON
  const handleExportData = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(actividades, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `Backup_Actividades_Proyectos_${referenceDate}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Importar base de datos de JSON
  const handleImportFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImportError('');
    setImportSuccess('');
    const fileReader = new FileReader();
    const files = e.target.files;
    if (!files || files.length === 0) return;

    fileReader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed)) {
          // Validación simple de esquema
          const isValid = parsed.every(item => 
            'wbs' in item && 
            'tipo_registro' in item && 
            'tarea' in item && 
            'estado' in item && 
            'inicio_planificado' in item && 
            'fin_planificado' in item
          );

          if (isValid) {
            const success = onImportData(parsed as Actividad[]);
            if (success) {
              setImportSuccess('¡Base de datos importada y restaurada exitosamente!');
              e.target.value = ''; // Reset input
            } else {
              setImportError('No se pudo procesar la importación debido a problemas de almacenamiento.');
            }
          } else {
            setImportError('El archivo JSON no coincide con el esquema requerido de Actividades.');
          }
        } else {
          setImportError('El formato de archivo debe ser una lista/array JSON de actividades.');
        }
      } catch (err) {
        setImportError('Error al leer el archivo. Asegúrese de que sea un JSON válido.');
      }
    };

    fileReader.readAsText(files[0]);
  };

  return (
    <div className="space-y-6 animate-fade-in" id="config-view-container">
      {/* Encabezado */}
      <div className="bg-[#11141B] p-6 rounded-2xl border border-[#1E293B] shadow-sm">
        <h2 className="text-xl font-bold text-[#E2E8F0] tracking-tight flex items-center gap-2">
          <Settings className="text-blue-500 h-5 w-5" />
          Configuración y Administración de Datos
        </h2>
        <p className="text-[#94A3B8] text-xs mt-1">
          Ajusta variables de control temporal del proyecto, realiza respaldos y administra plantillas demo de datos.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* PANEL IZQUIERDO: FECHA DE CONTROL DE AVANCES (SIMULACIÓN) */}
        <div className="bg-[#11141B] p-6 rounded-2xl border border-[#1E293B] shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-[#E2E8F0] uppercase tracking-wider flex items-center gap-1.5 border-b border-[#1E293B] pb-3">
            <Calendar className="text-blue-500 h-4 w-4" />
            Fecha de Control / Hoy
          </h3>
          <p className="text-xs text-[#94A3B8] leading-relaxed font-medium">
            La fecha actual se utiliza para calcular el <strong>Avance Planificado</strong> automático e identificar cuáles actividades están <strong>atrasadas</strong> si no tienen avance real completado.
          </p>

          <form onSubmit={handleDateSubmit} className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-[#E2E8F0]">Fecha de Simulación:</label>
              <input
                type="date"
                value={tempDate}
                onChange={(e) => setTempDate(e.target.value)}
                className="w-full p-2.5 bg-[#0A0C10] border border-[#1E293B] rounded-lg text-xs font-semibold focus:outline-hidden focus:ring-1 focus:ring-blue-500 text-[#E2E8F0] font-mono"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-[#E2E8F0] rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
            >
              Actualizar Fecha de Control
            </button>
          </form>

          <div className="p-3 bg-blue-500/5 text-blue-200 rounded-xl text-[11px] leading-relaxed border border-blue-500/10 font-medium">
            <span className="font-bold block mb-1">💡 ¿Para qué sirve?</span>
            Si avanzas esta fecha hacia adelante en el tiempo, verás cómo el <strong>Avance Planificado</strong> del proyecto aumenta automáticamente en base a los cronogramas definidos en la base de datos.
          </div>
        </div>

        {/* PANEL CENTRAL: RESPALDOS IMPORTACIÓN Y EXPORTACIÓN */}
        <div className="bg-[#11141B] p-6 rounded-2xl border border-[#1E293B] shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-[#E2E8F0] uppercase tracking-wider flex items-center gap-1.5 border-b border-[#1E293B] pb-3">
            <Database className="text-emerald-400 h-4 w-4" />
            Respaldos de Información
          </h3>
          <p className="text-xs text-[#94A3B8] leading-relaxed font-medium">
            Toda la planilla y cálculos se guardan de manera segura en tu navegador (<strong>localStorage</strong>). Puedes respaldar tus planillas o migrar tus datos.
          </p>

          <div className="space-y-3">
            {/* Exportar */}
            <button
              onClick={handleExportData}
              className="w-full py-2.5 bg-[#0A0C10] hover:bg-[#1E293B] border border-[#1E293B] text-[#E2E8F0] rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Download className="h-4 w-4 text-[#94A3B8]" />
              Respaldar Base de Datos (JSON)
            </button>

            {/* Importar */}
            <div className="space-y-1">
              <label className="text-[10px] font-black text-[#94A3B8] uppercase tracking-wider block">Importar desde Respaldo JSON:</label>
              <div className="relative border border-dashed border-[#1E293B] rounded-xl p-3 bg-[#0A0C10] hover:bg-[#1E293B]/60 transition-all text-center">
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="space-y-1">
                  <Upload className="h-5 w-5 text-[#94A3B8] mx-auto" />
                  <p className="text-xs font-bold text-[#E2E8F0]">Seleccionar Archivo .json</p>
                  <p className="text-[9px] text-[#94A3B8]">Restaurará todas las actividades.</p>
                </div>
              </div>
            </div>

            {/* Mensajes de Importación */}
            {importError && (
              <p className="text-[11px] text-rose-400 bg-rose-500/10 p-2 rounded-lg border border-rose-500/20 font-semibold">{importError}</p>
            )}
            {importSuccess && (
              <p className="text-[11px] text-emerald-400 bg-emerald-500/10 p-2 rounded-lg border border-emerald-500/20 font-semibold">{importSuccess}</p>
            )}
          </div>
        </div>

        {/* PANEL DERECHO: PLANTILLAS Y RECONSTRUCCIÓN */}
        <div className="bg-[#11141B] p-6 rounded-2xl border border-[#1E293B] shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-[#1E293B] pb-3">
            <Trash2 className="text-rose-500 h-4 w-4" />
            Acciones Peligrosas
          </h3>
          <p className="text-xs text-[#94A3B8] leading-relaxed font-medium">
            Permite restaurar la base de datos a la plantilla de ejemplo de ingeniería o realizar una limpieza total de las actividades registradas.
          </p>

          <div className="space-y-3 pt-2">
            {/* Cargar Demo */}
            <button
              onClick={() => {
                if (window.confirm('¿Deseas restaurar la base de datos de ejemplo? Esto sobreescribirá cualquier cambio manual que hayas hecho.')) {
                  onResetToDemoData();
                  alert('Base de datos de ejemplo de ingeniería restaurada correctamente.');
                }
              }}
              className="w-full py-2.5 bg-amber-500/5 hover:bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <RefreshCw className="h-4 w-4 text-amber-500" />
              Restablecer Datos de Ejemplo
            </button>

            {/* Borrado Total */}
            <button
              onClick={() => {
                if (window.confirm('⚠️ ATENCIÓN: ¿Estás totalmente seguro de que deseas vaciar y borrar toda la base de datos de actividades del proyecto? Esta acción es irreversible.')) {
                  onClearData();
                  alert('Base de datos vaciada. Todas las actividades fueron eliminadas.');
                }
              }}
              className="w-full py-2.5 bg-rose-500/10 hover:bg-rose-500/25 border border-rose-500/20 text-rose-400 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Trash2 className="h-4 w-4 text-rose-400" />
              Borrar Base de Datos Completa
            </button>
          </div>

          <div className="p-3 bg-rose-500/5 text-rose-300/90 rounded-xl text-[10px] leading-relaxed border border-rose-500/10 font-medium">
            <strong>Advertencia:</strong> Las operaciones anteriores limpian o reescriben los registros cargados de inmediato. Se recomienda hacer un respaldo de sus datos antes de continuar.
          </div>
        </div>

      </div>

      {/* FOOTER GENERAL DE INFORMACIÓN METODOLÓGICA */}
      <div className="bg-[#11141B] p-6 rounded-2xl border border-[#1E293B] space-y-3">
        <h3 className="text-xs font-black uppercase text-[#94A3B8] tracking-wider flex items-center gap-1.5">
          <HelpCircle className="h-4 w-4 text-[#94A3B8]" />
          FÓRMULAS DE AVANCES Y CONTROL APLICADAS (METODOLOGÍA DE INGENIERÍA)
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-[11px] text-[#94A3B8] leading-relaxed font-medium">
          <div className="space-y-1">
            <span className="font-bold text-[#E2E8F0] block">📅 Duraciones de Actividad:</span>
            <p>Calculado como <code className="bg-[#0A0C10] border border-[#1E293B] text-[#E2E8F0] px-1 rounded-sm">Fin - Inicio + 1 día</code>. Se aplica de igual manera para la Duración Planificada y la Duración Real.</p>
          </div>

          <div className="space-y-1">
            <span className="font-bold text-[#E2E8F0] block">📊 Avance General Ponderado:</span>
            <p>Si las actividades tienen asignado un <strong>Valor de Tarea</strong> (peso monetario o esfuerzo), el avance general del proyecto se calcula como:</p>
            <code className="block bg-[#0A0C10] border border-[#1E293B] text-[#E2E8F0] p-1.5 rounded-md mt-1 font-mono font-bold text-[10px]">
              ∑(Avance % * Valor Tarea) / ∑(Valor Tarea)
            </code>
            <p className="mt-1">Si los valores de tarea están vacíos o en cero, se aplicará un promedio simple general.</p>
          </div>

          <div className="space-y-1">
            <span className="font-bold text-[#E2E8F0] block">⚠️ Cálculo de Atrasos:</span>
            <p>Si el Estado no es <strong>Completada</strong> y superó su fecha planificada de finalización, el atraso en días se calcula dinámicamente comparando la fecha de finalización planificada contra la <strong>Fecha de Control</strong> activa.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
